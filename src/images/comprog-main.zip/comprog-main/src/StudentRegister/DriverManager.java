
package StudentRegister;


class DriverManager {

    static Connection getConnection(String jdbcmysqllocalhost3306user_system, String your_username, String your_password) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
}
