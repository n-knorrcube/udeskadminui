package StudentRegister;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySQLConnection {

    public static Connection getConnection() {
        try {
            // Replace these values with your actual database info
            String url = "jdbc:mysql://localhost:3306/user_system"; // Replace 'studentdb' with your database name
            String user = "root"; // Replace with your MySQL username
            String password = ""; // Replace with your MySQL password

            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect and return the connection
            return DriverManager.getConnection(url, user, password);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace(); // Print error if something goes wrong
            return null;
        }
    }
}
